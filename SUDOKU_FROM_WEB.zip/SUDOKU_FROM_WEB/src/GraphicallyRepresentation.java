/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 'http://imhasib.wordpress.com/2011/10/06/hello-world/'
 * copied from 'http://imhasib.wordpress.com/2011/10/06/hello-world/'
 */
import java.awt.*;
 import java.awt.event.*;
 import javax.swing.*;

import java.util.Random; //for random number
 
class GraphicallyRepresentation extends JFrame implements ActionListener
 {
 Container con;
 JButton b[][]=new JButton[9][9];
 TextField t[]=new TextField[61];
 JMenuBar mbar;
 JMenu file,option;
 JMenuItem submit,exit,about,Reset,Solution,easy,difficult,average;
 
int[][] cp=new int[9][9];
 int[][] ip=new int[9][9];
 int[][] original_ip=new int[9][9];
 //int[][] hideOption=new int[9][9];
 
GraphicallyRepresentation()
 {
 super("Play Sudoku .............(Created by farsim & hasib)");
 setSize(500,500);
 //setresizeable(false);
 
con=getContentPane();
 con.setLayout(new GridLayout(9,9));
 
Mylogic ob1=new Mylogic();
 ob1.complet_puzzle();
 ob1.puzzle();
 
int c=0;
 for(int i=0;i<9;i++)
 for(int j=0;j<9;j++)
 {
 b[i][j]=new JButton(""+ip[i][j]);
 b[i][j].setFont(new Font("ARIALBD",Font.BOLD,20));
 b[i][j].setForeground(Color.BLUE);
 if(ip[i][j]==0)
 {
 //b[i][j]=new JButton("");
 b[i][j].setText("0");
 b[i][j].setBackground(Color.WHITE);
 b[i][j].setForeground(Color.WHITE);
 b[i][j].addActionListener(this);
 
}
 
con.add(b[i][j]);
 
if(i==3 || i==4 || i==5 || j==3 || j==4 || j==5)
 {
 if(2<i) {
 b[i][j].setBackground(Color.CYAN);
 continue;
 }
 b[i][j].setBackground(Color.pink);
 
}
 
else
 b[i][j].setBackground(Color.CYAN);
 }
 
mbar=new JMenuBar();
 setJMenuBar(mbar);
 
file=new JMenu("File");
 option=new JMenu("Option");
 
 
 
about=new JMenuItem("About");
 Reset=new JMenuItem("reset");
 submit=new JMenuItem("Submit");
 exit=new JMenuItem("Exit");
 Solution=new JMenuItem("Solution");
 easy=new JMenuItem("Easy");
 difficult=new JMenuItem("Difficult");
 average=new JMenuItem("Average");
 
 Reset.addActionListener(
         new ActionListener(){
 public void actionPerformed(ActionEvent e)
 {
     for(int i=0;i<9;i++)
 for(int j=0;j<9;j++)
 {
 //ip contains the sudoku matrix with hidden values
 if(ip[i][j]==0)
 {
 //b[i][j]=new JButton("");
 b[i][j].setText("");
 b[i][j].setBackground(Color.WHITE);
 //b[i][j].addActionListener(this);
 
}
 
 }
 }
         });
 
submit.addActionListener(
 new ActionListener(){
 public void actionPerformed(ActionEvent e)
 {
 int r=0;
 
for(int i=0;i<9;i++)
 for(int j=0;j<9;j++)
 
 {
     
     if(Integer.parseInt(b[i][j].getText())!=cp[i][j])
         r=1;
 break;
 }

 
 
/*for(int i=0;i<9;i++)
 {
 System.out.println();
 for(int j=0;j<9;j++)
 {
 System.out.print(cp[i][j]);
 System.out.print(Integer.parseInt(b[i][j].getText())+" ");
 }}
 System.out.print("\n"+r);*/
 if(r==0)
 JOptionPane.showMessageDialog(GraphicallyRepresentation.this,"You won the Game");
 //System.out.println("You won the Game");
 else
 //System.out.println("You lose the Game");
 JOptionPane.showMessageDialog(GraphicallyRepresentation.this,"You lose the Game"); }
 
});

//Solution

Solution.addActionListener(
 new ActionListener(){
 public void actionPerformed(ActionEvent e)
 {
     for(int i=0;i<9;i++)
         for(int j=0;j<9;j++)
         {
             if(b[i][j].getText().equals(""))
             {
                 b[i][j].setForeground(Color.magenta);
     b[i][j].setText(""+cp[i][j]);}
    else if(!(b[i][j].getText().equals(""+cp[i][j])))
     {
         b[i][j].setBackground(Color.yellow);
       b[i][j].setForeground(Color.RED);
     b[i][j].setText(""+cp[i][j]);  
     }
             else
    {
      if (b[i][j].getForeground().equals(Color.GREEN))
        b[i][j].setForeground(Color.GREEN);
    }
     /*if(b[i][j].getText().equals(""+cp[i][j]))
     {
         b[i][j].setBackground(Color.BLACK);
       b[i][j].setForeground(Color.GREEN);
     b[i][j].setText(""+cp[i][j]);  
     }*/
     
  }
 }
 
});

//end of display solution
 exit.addActionListener(
 new ActionListener(){
 public void actionPerformed(ActionEvent e)
 {
 System.exit(0);
 }
 
});
 
about.addActionListener(
 new ActionListener(){
 public void actionPerformed(ActionEvent e)
 {
 JOptionPane.showMessageDialog( GraphicallyRepresentation.this,
 "FARSiM & HASiB JIgni Dost! SUST CSE 15batch PRODUCT....Our first project of java language ",
 "About", JOptionPane.PLAIN_MESSAGE );
 }
 }
 );

 easy.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
    ip=original_ip;
    int countZero=0;
    int row,column;
    Random H_Rnum=new Random();
    
    for(int x=0;x<9;x++)
        for(int y=0;y<9;y++){
            if(ip[x][y]==0)
                countZero++;
        }
    countZero=countZero-10;
    
    for(int x=0;x<9;x++)
        for(int y=0;y<9;y++)
        {
           row=H_Rnum.nextInt(9);
 column=H_Rnum.nextInt(9);
            if(countZero!=0)
            {
                if(ip[row][column]!=0)
                { 
                    continue;}
                else
                {
                    
 ip[row][column]=cp[row][column];//release info
 
 
                    
                }//end of else
                countZero--;
            }//end of if
           
            
        }//end of inner for
    //outer for has no brackets enclosure
    
      
     for(int i=0;i<9;i++)
 for(int j=0;j<9;j++)
 {
 //ip contains the sudoku matrix with hidden values
 if(ip[i][j]==0)
 {
 //b[i][j]=new JButton("");
 b[i][j].setText("");
 b[i][j].setBackground(Color.WHITE);}}
 //b[i][j].addActionListener(this);
     
}
    
 });
  difficult.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
      //ip=hide(70);
    JOptionPane.showMessageDialog( GraphicallyRepresentation.this,
 "Shall hide 10 more integers!!! ",
 "Difficult!!Way to go!!!", JOptionPane.PLAIN_MESSAGE );
   int row=0;
   int column=0;
   int i=0;
   Random H_Rnum=new Random();
   row=H_Rnum.nextInt(9);
 column=H_Rnum.nextInt(9);
  int count_Hidden=0;
   
    while(i<10)
    {
 
     int count_Given=0;
     for( i=0;i<9;i++)
    {
        
        for(int j=0;j<9;j++)
        {
            if(ip[i][j]==0) count_Hidden++;
           count_Given=81-count_Hidden;
     if(count_Given<=17)
            
            
             {  
     JOptionPane.showMessageDialog( GraphicallyRepresentation.this,
 "You are the most difficult level! ",
 "Cannot show further...!!!", JOptionPane.PLAIN_MESSAGE );
     break;
    
     }
    }
    }
if( ip[row][column]!=0)
{
    ip[row][column]=0;
    i++;
}//end of if
 
}//end of while
    for( i=0;i<9;i++)
 for(int j=0;j<9;j++)
 {
 //ip contains the sudoku matrix with hidden values
 if(ip[i][j]==0)
 {
 //b[i][j]=new JButton("");
 b[i][j].setText("");
 b[i][j].setBackground(Color.WHITE);
 //b[i][j].addActionListener(this);
 
}
 
 }
    
 }//end of actionPeformed
     
 });//end of ActionListener
   average.addActionListener(new ActionListener(){
public void actionPerformed(ActionEvent e){
      //ip=hide(70);
    JOptionPane.showMessageDialog( GraphicallyRepresentation.this,
 "Hides 5 more numbers!!! ",
 "Average!Slow and Steady!", JOptionPane.PLAIN_MESSAGE );
    
    
    
   int row=0;
   int column=0;
   int i=0;
   Random H_Rnum=new Random();
    while(i<5)
    {
 row=H_Rnum.nextInt(9);
 column=H_Rnum.nextInt(9);
if( ip[row][column]!=0)
{
    ip[row][column]=0;
    i++;
}//end of if
 
}//end of while
    for( i=0;i<9;i++)
 for(int j=0;j<9;j++)
 {
 //ip contains the sudoku matrix with hidden values
 if(ip[i][j]==0)
 {
 //b[i][j]=new JButton("");
 b[i][j].setText("");
 b[i][j].setBackground(Color.WHITE);
 //b[i][j].addActionListener(this);
 
}
 
 }
 }
     
 });
 
file.add(Reset);
 file.add(submit);
 file.add(Solution);
 file.addSeparator();
 file.add(exit);
 mbar.add(file);
 mbar.add(option);
 
 mbar.add(about);
 option.add(easy);
 option.add(difficult);
 option.add(average);
 
show();
 
//ob1.complet_puzzle();
 
MyWindowAdapter mwa=new MyWindowAdapter();
 addWindowListener(mwa);
 
}
 
class Mylogic extends logic
 {
 void complet_puzzle()
 {
 cp=save();
 
/*for(int i=0;i<9;i++)
 {
 for(int j=0;j<9;j++)
 System.out.print(cp[i][j]+" ");
 System.out.println();
 }*/
 }
 void puzzle()
 {
 ip=hide();
 original_ip=ip;
 /*System.out.print("\n\n\n"+"nhiding puzzle :\n");
 for(int i=0;i<9;i++)
 {
 for(int j=0;j<9;j++)
 System.out.print(ip[i][j]+" ");
 System.out.println();
 }*/
 }
 
}
 
class MyWindowAdapter extends WindowAdapter
 {
 public void windowClosing(WindowEvent e)
 {
 System.exit(0);
 }
 }
 
public void actionPerformed(ActionEvent e)
 {
 for(int i=0;i<9;i++)
 for(int j=0;j<9;j++)
 {
     int c=0;
 if(e.getSource()==b[i][j])
 {
 String s=JOptionPane.showInputDialog("enter your number");
 if           (!("".equals(s))||(s.equals(null)))
  c=Integer.parseInt(s);
 
 else 
     while(   (  "".equals(s))||s.equals(null))
     s=JOptionPane.showInputDialog("That was a null value!Please enter a number between 1 and 9!!!");
 if(c!=0)
 {
 b[i][j].setText(s);
 //b[i][j].setBackground(Color.GRAY);
 b[i][j].setFont(new Font("ARIALBD",Font.BOLD,25));
 if(c==cp[i][j])
 b[i][j].setForeground(Color.GREEN);
 else
     b[i][j].setForeground(Color.RED);
 }
 
break;
 }
 }
 }
 void recall()
 {
 GraphicallyRepresentation rs=new GraphicallyRepresentation();
 }
 
public static void main (String[] args) {
 GraphicallyRepresentation ob=new GraphicallyRepresentation();
 
}
 }
