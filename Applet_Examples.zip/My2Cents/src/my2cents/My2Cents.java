/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package my2cents;

/**
 *
 * @author shanki_1974
 */
public class My2Cents {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // TODO code application logic here    
        System.out.println("Hello World!!!");
    }
       
}
